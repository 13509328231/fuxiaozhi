'use client';

import React from 'react';
import { AppProvider, useApp } from '@/context/AppContext';
import LoginPage from '@/components/LoginPage';
import Sidebar from '@/components/Sidebar';
import MainContent from '@/components/MainContent';
import FloatingBall from '@/components/FloatingBall';
import { cn } from '@/lib/utils';

function AppContent() {
  const { isLoggedIn, windowState } = useApp();

  // 未登录状态
  if (!isLoggedIn) {
    return <LoginPage />;
  }

  // 最小化状态 - 仅显示悬浮球
  if (windowState === 'minimized') {
    return <FloatingBall />;
  }

  // 主界面
  return (
    <div className="h-screen w-screen flex items-center justify-center bg-gradient-to-br from-slate-100 via-slate-50 to-blue-50 p-4">
      {/* 主窗口 */}
      <div 
        className={cn(
          "flex bg-white rounded-2xl shadow-2xl overflow-hidden transition-all duration-300",
          "w-[1200px] h-[700px]"
        )}
        style={{ maxWidth: '95vw', maxHeight: '90vh' }}
      >
        {/* 左侧导航栏 */}
        <Sidebar />
        
        {/* 主内容区（包含嵌入式输入栏） */}
        <MainContent />
      </div>
    </div>
  );
}

export default function Home() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
