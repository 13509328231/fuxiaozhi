'use client';

import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { Skill, App, AppCategory, KnowledgeBase, AIModel, WindowState, User, Creation, HistoryRecord, FavoriteItem, Message } from '@/types';

// 默认技能列表
const defaultSkills: Skill[] = [
  { id: 'doc-writer', name: '公文写作助手', icon: '📝', description: '智能公文写作与润色', category: 'common' },
  { id: 'data-analysis', name: '数据分析助手', icon: '📊', description: '数据可视化与分析', category: 'common' },
  { id: 'ppt-gen', name: 'PPT生成', icon: '📽️', description: '智能PPT生成', category: 'common' },
  { id: 'weekly-report', name: '周报生成', icon: '📋', description: '自动生成周报', category: 'common' },
  { id: 'image-gen', name: '图片生成助手', icon: '🎨', description: 'AI图片生成', category: 'common' },
  { id: 'video-gen', name: '视频生成', icon: '🎬', description: 'AI视频生成', category: 'common' },
  { id: 'meeting', name: '会议助手', icon: '🎙️', description: '会议纪要智能生成', category: 'common' },
  { id: 'claw', name: '小智Claw', icon: '💻', description: '代码与命令行交互', category: 'common' },
];

// 默认模型列表
const defaultModels: AIModel[] = [
  { id: 'jiutian', name: '九天大模型', provider: '中国移动' },
  { id: 'deepseek', name: 'DeepSeek', provider: 'DeepSeek' },
  { id: 'kimi', name: 'Kimi 2.5', provider: '月之暗面' },
  { id: 'doubao', name: '豆包', provider: '字节跳动' },
];

// 默认知识库列表
const defaultKnowledgeBases: KnowledgeBase[] = [
  { id: 'general', name: '通用知识库', type: 'personal' },
  { id: 'party', name: '党政知识库', type: 'shared' },
  { id: 'management', name: '管理办法知识库', type: 'shared' },
  { id: 'industry', name: '行业资讯', type: 'industry' },
];

// 应用分类颜色
const categoryColors: Record<string, string> = {
  '市场': 'bg-blue-100 text-blue-600',
  '政企': 'bg-red-100 text-red-600',
  '综合': 'bg-purple-100 text-purple-600',
  '信安': 'bg-orange-100 text-orange-600',
  '管理': 'bg-green-100 text-green-600',
  '人力': 'bg-pink-100 text-pink-600',
  '财务': 'bg-yellow-100 text-yellow-600',
  '网络': 'bg-cyan-100 text-cyan-600',
  '数智': 'bg-indigo-100 text-indigo-600',
};

// 生成随机应用
const generateApps = (): App[] => {
  const categories: AppCategory[] = ['市场', '政企', '综合', '信安', '管理', '人力', '财务', '网络', '数智'];
  const apps: App[] = [];
  
  const appNames = [
    '智能客服', '文档助手', '数据分析平台', '项目管理', '流程审批',
    '报表中心', '知识问答', '智能检索', '会议管理', '任务协作',
    'CRM系统', 'OA办公', '财务管理', '人事管理', '合同管理',
    '采购管理', '资产管理', '数据治理', '智能运维', '安全审计',
  ];
  
  appNames.forEach((name, index) => {
    apps.push({
      id: `app-${index}`,
      name,
      category: categories[index % categories.length],
      description: `${name}应用描述`,
      isFavorite: false,
    });
  });
  
  return apps;
};

interface AppState {
  // 登录状态
  isLoggedIn: boolean;
  user: User | null;
  
  // 窗口状态
  windowState: WindowState;
  sidebarCollapsed: boolean;
  
  // 当前激活的技能
  activeSkill: Skill | null;
  
  // 当前页面
  currentPage: 'home' | 'skills' | 'apps' | 'knowledge' | 'my-space';
  
  // 技能列表
  skills: Skill[];
  customSkills: Skill[];
  
  // 应用列表
  apps: App[];
  
  // 知识库
  knowledgeBases: KnowledgeBase[];
  selectedKnowledgeBase: KnowledgeBase;
  
  // 模型
  models: AIModel[];
  selectedModel: AIModel;
  
  // 联网搜索
  webSearchEnabled: boolean;
  
  // 对话消息
  messages: Message[];
  
  // 创作内容
  creations: Creation[];
  
  // 历史记录
  historyRecords: HistoryRecord[];
  
  // 收藏
  favorites: FavoriteItem[];
}

interface AppContextType extends AppState {
  // 登录登出
  login: (user: User) => void;
  logout: () => void;
  
  // 窗口控制
  setWindowState: (state: WindowState) => void;
  toggleSidebar: () => void;
  
  // 技能操作
  setActiveSkill: (skill: Skill | null) => void;
  addCustomSkill: (skill: Skill) => void;
  removeSkill: (skillId: string) => void;
  
  // 应用操作
  toggleAppFavorite: (appId: string) => void;
  
  // 页面导航
  setCurrentPage: (page: AppState['currentPage']) => void;
  
  // 模型与知识库
  setSelectedModel: (model: AIModel) => void;
  setSelectedKnowledgeBase: (kb: KnowledgeBase) => void;
  toggleWebSearch: () => void;
  
  // 消息
  addMessage: (message: Message) => void;
  clearMessages: () => void;
  
  // 创作管理
  addCreation: (creation: Creation) => void;
  deleteCreation: (id: string) => void;
  
  // 历史记录
  addHistoryRecord: (record: HistoryRecord) => void;
  
  // 收藏
  addFavorite: (item: FavoriteItem) => void;
  removeFavorite: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>({
    isLoggedIn: false,
    user: null,
    windowState: 'normal',
    sidebarCollapsed: false,
    activeSkill: null,
    currentPage: 'home',
    skills: defaultSkills,
    customSkills: [],
    apps: generateApps(),
    knowledgeBases: defaultKnowledgeBases,
    selectedKnowledgeBase: defaultKnowledgeBases[0],
    models: defaultModels,
    selectedModel: defaultModels[0],
    webSearchEnabled: false,
    messages: [],
    creations: [],
    historyRecords: [],
    favorites: [],
  });

  const login = useCallback((user: User) => {
    setState(prev => ({ ...prev, isLoggedIn: true, user }));
  }, []);

  const logout = useCallback(() => {
    setState(prev => ({ 
      ...prev, 
      isLoggedIn: false, 
      user: null,
      activeSkill: null,
      currentPage: 'home',
      messages: [],
    }));
  }, []);

  const setWindowState = useCallback((windowState: WindowState) => {
    setState(prev => ({ ...prev, windowState }));
  }, []);

  const toggleSidebar = useCallback(() => {
    setState(prev => ({ ...prev, sidebarCollapsed: !prev.sidebarCollapsed }));
  }, []);

  const setActiveSkill = useCallback((skill: Skill | null) => {
    setState(prev => ({ 
      ...prev, 
      activeSkill: skill,
      currentPage: 'home',
      messages: [],
    }));
  }, []);

  const addCustomSkill = useCallback((skill: Skill) => {
    setState(prev => ({
      ...prev,
      customSkills: [...prev.customSkills, { ...skill, category: 'custom' }],
    }));
  }, []);

  const removeSkill = useCallback((skillId: string) => {
    setState(prev => ({
      ...prev,
      customSkills: prev.customSkills.filter(s => s.id !== skillId),
      activeSkill: prev.activeSkill?.id === skillId ? null : prev.activeSkill,
    }));
  }, []);

  const toggleAppFavorite = useCallback((appId: string) => {
    setState(prev => ({
      ...prev,
      apps: prev.apps.map(app =>
        app.id === appId ? { ...app, isFavorite: !app.isFavorite } : app
      ),
    }));
  }, []);

  const setCurrentPage = useCallback((currentPage: AppState['currentPage']) => {
    setState(prev => ({ 
      ...prev, 
      currentPage,
      activeSkill: null,
    }));
  }, []);

  const setSelectedModel = useCallback((selectedModel: AIModel) => {
    setState(prev => ({ ...prev, selectedModel }));
  }, []);

  const setSelectedKnowledgeBase = useCallback((selectedKnowledgeBase: KnowledgeBase) => {
    setState(prev => ({ ...prev, selectedKnowledgeBase }));
  }, []);

  const toggleWebSearch = useCallback(() => {
    setState(prev => ({ ...prev, webSearchEnabled: !prev.webSearchEnabled }));
  }, []);

  const addMessage = useCallback((message: Message) => {
    setState(prev => ({ ...prev, messages: [...prev.messages, message] }));
  }, []);

  const clearMessages = useCallback(() => {
    setState(prev => ({ ...prev, messages: [] }));
  }, []);

  const addCreation = useCallback((creation: Creation) => {
    setState(prev => ({ ...prev, creations: [creation, ...prev.creations] }));
  }, []);

  const deleteCreation = useCallback((id: string) => {
    setState(prev => ({
      ...prev,
      creations: prev.creations.filter(c => c.id !== id),
    }));
  }, []);

  const addHistoryRecord = useCallback((record: HistoryRecord) => {
    setState(prev => ({ ...prev, historyRecords: [record, ...prev.historyRecords] }));
  }, []);

  const addFavorite = useCallback((item: FavoriteItem) => {
    setState(prev => ({ ...prev, favorites: [...prev.favorites, item] }));
  }, []);

  const removeFavorite = useCallback((id: string) => {
    setState(prev => ({
      ...prev,
      favorites: prev.favorites.filter(f => f.id !== id),
    }));
  }, []);

  const value: AppContextType = {
    ...state,
    login,
    logout,
    setWindowState,
    toggleSidebar,
    setActiveSkill,
    addCustomSkill,
    removeSkill,
    toggleAppFavorite,
    setCurrentPage,
    setSelectedModel,
    setSelectedKnowledgeBase,
    toggleWebSearch,
    addMessage,
    clearMessages,
    addCreation,
    deleteCreation,
    addHistoryRecord,
    addFavorite,
    removeFavorite,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}

export { categoryColors };
