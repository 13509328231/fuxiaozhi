'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import Image from 'next/image';
import { 
  Search, 
  FileText, 
  Image as ImageIcon,
  Video,
  Presentation,
  ClipboardList,
  Star,
  Trash2,
  Edit2,
  Eye,
  Clock,
  Grid,
  LayoutList,
  Settings,
  ExternalLink,
  MessageSquare,
} from 'lucide-react';
import { Creation, ContentType, HistoryRecord, FavoriteItem } from '@/types';
import FeedbackPage from './FeedbackPage';

// 模拟创作内容
const mockCreations: Creation[] = [
  { id: 'c1', title: '2024年度工作总结PPT', type: 'ppt', createdAt: new Date('2024-01-15'), updatedAt: new Date('2024-01-15') },
  { id: 'c2', title: '项目需求分析报告', type: 'document', createdAt: new Date('2024-01-14'), updatedAt: new Date('2024-01-14') },
  { id: 'c3', title: '产品宣传海报', type: 'image', createdAt: new Date('2024-01-13'), updatedAt: new Date('2024-01-13') },
  { id: 'c4', title: '产品介绍视频', type: 'video', createdAt: new Date('2024-01-12'), updatedAt: new Date('2024-01-12') },
  { id: 'c5', title: '本周工作周报', type: 'report', createdAt: new Date('2024-01-11'), updatedAt: new Date('2024-01-11') },
];

// 模拟历史记录
const mockHistory: HistoryRecord[] = [
  { id: 'h1', title: 'PPT生成 - 年度总结', skillId: 'ppt-gen', createdAt: new Date('2024-01-15 14:30'), preview: '生成了一份关于2024年度工作总结的演示文稿...' },
  { id: 'h2', title: '公文写作 - 请示报告', skillId: 'doc-writer', createdAt: new Date('2024-01-15 10:20'), preview: '撰写了一份关于项目验收的请示报告...' },
  { id: 'h3', title: '数据分析 - 销售报表', skillId: 'data-analysis', createdAt: new Date('2024-01-14 16:45'), preview: '分析了2024年Q1销售数据趋势...' },
  { id: 'h4', title: '图片生成 - 产品海报', skillId: 'image-gen', createdAt: new Date('2024-01-14 09:15'), preview: '生成了一张科技感产品宣传海报...' },
  { id: 'h5', title: '会议助手 - 项目评审会', skillId: 'meeting', createdAt: new Date('2024-01-13 15:00'), preview: '整理了项目评审会议纪要...' },
];

// 模拟收藏
const mockFavorites: FavoriteItem[] = [
  { id: 'f1', type: 'skill', title: 'PPT生成', referenceId: 'ppt-gen', createdAt: new Date('2024-01-10') },
  { id: 'f2', type: 'conversation', title: '产品规划讨论', referenceId: 'conv-1', createdAt: new Date('2024-01-12') },
  { id: 'f3', type: 'knowledge', title: '党政政策文件库', referenceId: 'kb-1', createdAt: new Date('2024-01-13') },
  { id: 'f4', type: 'app', title: '智能客服', referenceId: 'app-1', createdAt: new Date('2024-01-14') },
];

const typeIcons: Record<ContentType, React.ReactNode> = {
  ppt: <Presentation className="w-5 h-5" />,
  document: <FileText className="w-5 h-5" />,
  image: <ImageIcon className="w-5 h-5" />,
  video: <Video className="w-5 h-5" />,
  report: <ClipboardList className="w-5 h-5" />,
};

const typeColors: Record<ContentType, string> = {
  ppt: 'bg-orange-100 text-orange-500',
  document: 'bg-blue-100 text-blue-500',
  image: 'bg-purple-100 text-purple-500',
  video: 'bg-pink-100 text-pink-500',
  report: 'bg-green-100 text-green-500',
};

const favoriteTypeLabels: Record<string, string> = {
  skill: '技能',
  conversation: '对话',
  knowledge: '知识库',
  app: '应用',
};

export default function MySpace() {
  const { user, skills } = useApp();
  const [activeTab, setActiveTab] = useState('creations');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedType, setSelectedType] = useState<ContentType | 'all'>('all');
  const [showFeedback, setShowFeedback] = useState(false);

  // 显示反馈页面
  if (showFeedback) {
    return <FeedbackPage onBack={() => setShowFeedback(false)} />;
  }

  const filteredCreations = mockCreations.filter(c => {
    const matchesSearch = c.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = selectedType === 'all' || c.type === selectedType;
    return matchesSearch && matchesType;
  });

  return (
    <div className="flex-1 p-6 overflow-auto">
      <div className="max-w-6xl mx-auto">
        {/* 用户信息头部 */}
        <div className="flex items-center gap-4 mb-6">
          <div className="w-16 h-16 rounded-full overflow-hidden bg-gradient-to-br from-blue-400 to-indigo-500 p-0.5">
            <Image 
              src="/logo.png" 
              alt="用户头像" 
              width={64} 
              height={64}
              className="rounded-full object-cover"
            />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-800">我的空间</h1>
            <p className="text-slate-500 mt-0.5">管理您的创作内容、历史记录和收藏</p>
          </div>
          
          {/* 服务反馈入口 - 简化为图标 */}
          <button
            onClick={() => setShowFeedback(true)}
            className="ml-auto p-2.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
            title="服务反馈"
          >
            <MessageSquare className="w-5 h-5" />
          </button>
        </div>

        {/* 主内容区 */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="bg-slate-100 h-11 p-1">
            <TabsTrigger value="creations" className="data-[state=active]:bg-white data-[state=active]:shadow-sm">
              <FileText className="w-4 h-4 mr-2" />
              创作内容
            </TabsTrigger>
            <TabsTrigger value="history" className="data-[state=active]:bg-white data-[state=active]:shadow-sm">
              <Clock className="w-4 h-4 mr-2" />
              历史记录
            </TabsTrigger>
            <TabsTrigger value="favorites" className="data-[state=active]:bg-white data-[state=active]:shadow-sm">
              <Star className="w-4 h-4 mr-2" />
              收藏夹
            </TabsTrigger>
            <TabsTrigger value="skills" className="data-[state=active]:bg-white data-[state=active]:shadow-sm">
              <Settings className="w-4 h-4 mr-2" />
              我的技能
            </TabsTrigger>
          </TabsList>

          {/* 创作内容 */}
          <TabsContent value="creations">
            <div className="flex items-center gap-4 mb-4">
              <div className="relative flex-1 max-w-sm">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="搜索创作内容..."
                  className="pl-10"
                />
              </div>
              <div className="flex items-center gap-1 bg-slate-100 rounded-lg p-1">
                <Button
                  variant={viewMode === 'grid' ? 'outline' : 'ghost'}
                  size="icon"
                  onClick={() => setViewMode('grid')}
                  className="h-8 w-8"
                >
                  <Grid className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'outline' : 'ghost'}
                  size="icon"
                  onClick={() => setViewMode('list')}
                  className="h-8 w-8"
                >
                  <LayoutList className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* 类型筛选 */}
            <div className="flex gap-2 mb-4">
              {(['all', 'ppt', 'document', 'image', 'video', 'report'] as const).map((type) => (
                <Button
                  key={type}
                  variant={selectedType === type ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedType(type)}
                >
                  {type === 'all' ? '全部' : type.toUpperCase()}
                </Button>
              ))}
            </div>

            {viewMode === 'grid' ? (
              <div className="grid grid-cols-4 gap-4">
                {filteredCreations.map((creation) => (
                  <Card key={creation.id} className="border-slate-200 hover:shadow-md transition-shadow cursor-pointer group">
                    <CardContent className="p-4">
                      <div className={`w-12 h-12 rounded-xl ${typeColors[creation.type]} flex items-center justify-center mb-3`}>
                        {typeIcons[creation.type]}
                      </div>
                      <h3 className="font-medium text-slate-800 truncate">{creation.title}</h3>
                      <p className="text-xs text-slate-400 mt-1">
                        {creation.createdAt.toLocaleDateString()}
                      </p>
                      <div className="flex gap-1 mt-3 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <Eye className="w-3.5 h-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <Edit2 className="w-3.5 h-3.5" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-red-400 hover:text-red-500">
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="space-y-2">
                {filteredCreations.map((creation) => (
                  <Card key={creation.id} className="border-slate-200 hover:shadow-md transition-shadow cursor-pointer">
                    <CardContent className="p-3 flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-lg ${typeColors[creation.type]} flex items-center justify-center`}>
                        {typeIcons[creation.type]}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-slate-800">{creation.title}</h3>
                        <p className="text-xs text-slate-400">{creation.createdAt.toLocaleDateString()}</p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="ghost" size="sm">
                          <Eye className="w-4 h-4 mr-1" />
                          预览
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Edit2 className="w-4 h-4 mr-1" />
                          编辑
                        </Button>
                        <Button variant="ghost" size="sm" className="text-red-400 hover:text-red-500">
                          <Trash2 className="w-4 h-4 mr-1" />
                          删除
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* 历史记录 */}
          <TabsContent value="history">
            <div className="relative mb-4 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input
                placeholder="搜索历史记录..."
                className="pl-10"
              />
            </div>
            <div className="space-y-2">
              {mockHistory.map((record) => {
                const skill = skills.find(s => s.id === record.skillId);
                return (
                  <Card key={record.id} className="border-slate-200 hover:shadow-md transition-shadow cursor-pointer">
                    <CardContent className="p-3 flex items-center gap-4">
                      <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center text-xl">
                        {skill?.icon || '📝'}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-slate-800">{record.title}</h3>
                        <p className="text-sm text-slate-500 truncate">{record.preview}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-slate-400">{record.createdAt.toLocaleDateString()}</p>
                        <p className="text-xs text-slate-400">{record.createdAt.toLocaleTimeString()}</p>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          {/* 收藏夹 */}
          <TabsContent value="favorites">
            <div className="grid grid-cols-2 gap-4">
              {mockFavorites.map((item) => (
                <Card key={item.id} className="border-slate-200 hover:shadow-md transition-shadow cursor-pointer">
                  <CardContent className="p-4 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-yellow-100 flex items-center justify-center">
                      <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-slate-800">{item.title}</h3>
                      <Badge variant="outline" className="text-xs mt-1">{favoriteTypeLabels[item.type]}</Badge>
                    </div>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-red-400 hover:text-red-500">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* 我的技能 */}
          <TabsContent value="skills">
            <Card className="border-slate-200">
              <CardHeader>
                <CardTitle className="text-base">已订阅技能</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-3">
                  {skills.map((skill) => (
                    <div
                      key={skill.id}
                      className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg hover:bg-slate-100 cursor-pointer"
                    >
                      <span className="text-2xl">{skill.icon}</span>
                      <div className="flex-1">
                        <p className="font-medium text-slate-700">{skill.name}</p>
                        <p className="text-xs text-slate-400">{skill.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
