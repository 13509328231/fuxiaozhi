'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { User, Lock, Smartphone, ArrowRight } from 'lucide-react';
import Image from 'next/image';

export default function LoginPage() {
  const { login } = useApp();
  const [activeTab, setActiveTab] = useState('account');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [simNumber, setSimNumber] = useState('');

  const handleLogin = () => {
    // 不做实际校验，直接登录
    login({
      id: '1',
      name: username || '用户',
      avatar: undefined,
    });
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* 背景装饰 */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-blue-200/30 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-indigo-200/30 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-purple-200/20 rounded-full blur-3xl" />
      </div>

      {/* 登录卡片 */}
      <Card className="relative w-[420px] shadow-xl border-0 bg-white/80 backdrop-blur-sm">
        <CardContent className="p-8">
          {/* Logo和标题 */}
          <div className="flex flex-col items-center mb-8">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center mb-4 shadow-lg shadow-blue-500/25">
              <Image 
                src="/logo.png" 
                alt="福小智" 
                width={48} 
                height={48}
                className="rounded-xl"
              />
            </div>
            <h1 className="text-2xl font-semibold text-slate-800">福小智</h1>
            <p className="text-sm text-slate-500 mt-1">多模态智能助手</p>
          </div>

          {/* 登录方式切换 */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-slate-100/80 h-11">
              <TabsTrigger 
                value="account" 
                className="data-[state=active]:bg-white data-[state=active]:shadow-sm"
              >
                <User className="w-4 h-4 mr-2" />
                账号密码
              </TabsTrigger>
              <TabsTrigger 
                value="sim"
                className="data-[state=active]:bg-white data-[state=active]:shadow-sm"
              >
                <Smartphone className="w-4 h-4 mr-2" />
                SIM卡认证
              </TabsTrigger>
            </TabsList>

            <TabsContent value="account" className="mt-6 space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">账号</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    type="text"
                    placeholder="请输入账号"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="pl-10 h-11 bg-slate-50/50 border-slate-200 focus:border-blue-400 focus:ring-blue-400/20"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">密码</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    type="password"
                    placeholder="请输入密码"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 h-11 bg-slate-50/50 border-slate-200 focus:border-blue-400 focus:ring-blue-400/20"
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="sim" className="mt-6 space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">SIM卡号</label>
                <div className="relative">
                  <Smartphone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <Input
                    type="text"
                    placeholder="请输入SIM卡号"
                    value={simNumber}
                    onChange={(e) => setSimNumber(e.target.value)}
                    className="pl-10 h-11 bg-slate-50/50 border-slate-200 focus:border-blue-400 focus:ring-blue-400/20"
                  />
                </div>
              </div>
              <p className="text-xs text-slate-500 bg-slate-50 rounded-lg p-3">
                SIM卡认证需确保您的设备已插入对应SIM卡，并开启数据网络
              </p>
            </TabsContent>
          </Tabs>

          {/* 登录按钮 */}
          <Button
            onClick={handleLogin}
            className="w-full mt-6 h-11 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 shadow-lg shadow-blue-500/25 transition-all"
          >
            登录
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>

          {/* 底部信息 */}
          <div className="mt-6 text-center text-xs text-slate-400">
            <p>© 2024 中国移动 · 福小智智能助手</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
