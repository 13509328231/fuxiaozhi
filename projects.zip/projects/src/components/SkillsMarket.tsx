'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Search, 
  Star, 
  Plus,
  TrendingUp,
  Clock,
  Users,
} from 'lucide-react';

interface MarketSkill {
  id: string;
  name: string;
  icon: string;
  description: string;
  category: string;
  users: number;
  rating: number;
  isNew?: boolean;
}

const marketSkills: MarketSkill[] = [
  { id: 'm1', name: 'AI翻译', icon: '🌐', description: '多语言智能翻译', category: '办公', users: 12500, rating: 4.8, isNew: true },
  { id: 'm2', name: '智能校对', icon: '✏️', description: '文档智能校对与润色', category: '办公', users: 8900, rating: 4.6 },
  { id: 'm3', name: '合同审查', icon: '📋', description: '智能合同审查与分析', category: '法务', users: 5600, rating: 4.7 },
  { id: 'm4', name: '数据可视化', icon: '📊', description: '智能数据图表生成', category: '数据', users: 15200, rating: 4.9, isNew: true },
  { id: 'm5', name: '简历优化', icon: '📄', description: '简历智能优化建议', category: '人力', users: 7800, rating: 4.5 },
  { id: 'm6', name: '代码助手', icon: '💻', description: '智能代码生成与调试', category: '开发', users: 25000, rating: 4.8 },
  { id: 'm7', name: '智能客服', icon: '🤖', description: 'AI客服话术生成', category: '服务', users: 9500, rating: 4.6 },
  { id: 'm8', name: '方案撰写', icon: '📝', description: '智能方案生成', category: '办公', users: 11200, rating: 4.7 },
  { id: 'm9', name: '舆情分析', icon: '📈', description: '网络舆情智能分析', category: '数据', users: 4300, rating: 4.5, isNew: true },
  { id: 'm10', name: '发票识别', icon: '🧾', description: '智能发票识别与录入', category: '财务', users: 6700, rating: 4.6 },
  { id: 'm11', name: '会议预约', icon: '📅', description: '智能会议时间协调', category: '办公', users: 8200, rating: 4.4 },
  { id: 'm12', name: '邮件助手', icon: '📧', description: '智能邮件撰写与回复', category: '办公', users: 13500, rating: 4.7 },
];

const categories = ['全部', '办公', '数据', '开发', '法务', '人力', '财务', '服务'];

export default function SkillsMarket() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('全部');
  const { addCustomSkill } = useApp();

  const filteredSkills = marketSkills.filter(skill => {
    const matchesSearch = skill.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         skill.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === '全部' || skill.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleSubscribe = (skill: MarketSkill) => {
    addCustomSkill({
      id: skill.id,
      name: skill.icon + ' ' + skill.name,
      icon: skill.icon,
      description: skill.description,
      category: 'custom',
    });
  };

  return (
    <div className="flex-1 p-6 overflow-auto">
      <div className="max-w-6xl mx-auto">
        {/* 标题区 */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-slate-800">技能广场</h1>
          <p className="text-slate-500 mt-1">发现更多智能技能，提升工作效率</p>
        </div>

        {/* 搜索和筛选 */}
        <div className="flex gap-4 mb-6">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="搜索技能..."
              className="pl-10 bg-white border-slate-200"
            />
          </div>
        </div>

        {/* 分类标签 */}
        <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="mb-6">
          <TabsList className="bg-slate-100 h-auto p-1 flex-wrap">
            {categories.map((cat) => (
              <TabsTrigger 
                key={cat} 
                value={cat}
                className="data-[state=active]:bg-white data-[state=active]:shadow-sm px-4"
              >
                {cat}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>

        {/* 热门推荐 */}
        <div className="mb-8 bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 rounded-xl p-5 border border-orange-100/50">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-orange-500" />
            <h2 className="text-lg font-semibold text-slate-700">热门推荐</h2>
          </div>
          <div className="grid grid-cols-4 gap-4">
            {marketSkills.filter(s => s.isNew).slice(0, 4).map((skill) => (
              <Card key={skill.id} className="border-white/50 bg-white/80 backdrop-blur-sm hover:shadow-md transition-all cursor-pointer group hover:bg-white">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-100 to-amber-100 flex items-center justify-center text-2xl group-hover:scale-110 transition-transform shadow-sm">
                      {skill.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium text-slate-800 truncate">{skill.name}</h3>
                        {skill.isNew && (
                          <Badge variant="secondary" className="text-xs bg-orange-500 text-white border-0">新</Badge>
                        )}
                      </div>
                      <p className="text-sm text-slate-500 mt-0.5 truncate">{skill.description}</p>
                      <div className="flex items-center gap-3 mt-2 text-xs text-slate-400">
                        <span className="flex items-center gap-1">
                          <Users className="w-3 h-3" />
                          {(skill.users / 1000).toFixed(1)}k
                        </span>
                        <span className="flex items-center gap-1">
                          <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                          {skill.rating}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* 全部技能 */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Clock className="w-5 h-5 text-blue-500" />
            <h2 className="text-lg font-semibold text-slate-700">全部技能</h2>
          </div>
          <div className="grid grid-cols-3 gap-4">
            {filteredSkills.map((skill) => (
              <Card key={skill.id} className="border-slate-200 hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-11 h-11 rounded-xl bg-slate-100 flex items-center justify-center text-xl">
                      {skill.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium text-slate-800">{skill.name}</h3>
                        <Badge variant="outline" className="text-xs">{skill.category}</Badge>
                      </div>
                      <p className="text-sm text-slate-500 mt-0.5">{skill.description}</p>
                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center gap-2 text-xs text-slate-400">
                          <span className="flex items-center gap-1">
                            <Users className="w-3 h-3" />
                            {(skill.users / 1000).toFixed(1)}k使用
                          </span>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleSubscribe(skill)}
                          className="h-7 text-xs"
                        >
                          <Plus className="w-3 h-3 mr-1" />
                          订阅
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
