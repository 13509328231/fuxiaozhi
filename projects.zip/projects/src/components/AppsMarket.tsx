'use client';

import React, { useState } from 'react';
import { useApp, categoryColors } from '@/context/AppContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { 
  Search, 
  Heart,
  User,
  Star,
  TrendingUp,
  Sparkles,
  ChevronRight,
} from 'lucide-react';
import { App, AppCategory } from '@/types';

const appCategories: AppCategory[] = ['市场', '政企', '综合', '信安', '管理', '人力', '财务', '网络', '数智'];

// 推荐应用数据
const recommendedApps = [
  { id: 'rec-1', name: '智能客服', category: '市场', description: 'AI驱动的智能客服解决方案', hot: true, tag: '热门' },
  { id: 'rec-2', name: '数据分析平台', category: '综合', description: '一站式数据分析与可视化', hot: false, tag: '新品' },
  { id: 'rec-3', name: '知识问答', category: '数智', description: '企业知识库智能问答系统', hot: true, tag: '精选' },
  { id: 'rec-4', name: '流程审批', category: '政企', description: '高效的企业级流程审批', hot: false, tag: '推荐' },
];

// 扩展应用数据，添加描述和创作者
const enhancedApps = [
  { id: 'app-0', name: '智能客服', category: '市场', description: '基于AI的智能客服系统，支持多轮对话、意图识别、自动回复等功能，提升客户服务效率', creator: '数智团队', isFavorite: false },
  { id: 'app-1', name: '文档助手', category: '政企', description: '智能文档处理工具，支持文档格式转换、内容提取、智能校对等功能', creator: '办公应用组', isFavorite: false },
  { id: 'app-2', name: '数据分析平台', category: '综合', description: '一站式数据分析平台，支持数据可视化、报表生成、趋势预测等功能', creator: '数据智能部', isFavorite: false },
  { id: 'app-3', name: '项目管理', category: '管理', description: '项目全生命周期管理工具，支持任务分配、进度跟踪、资源调度等功能', creator: '效率工具组', isFavorite: false },
  { id: 'app-4', name: '流程审批', category: '政企', description: '企业级流程审批系统，支持自定义流程、移动审批、数据分析等功能', creator: '政务应用部', isFavorite: false },
  { id: 'app-5', name: '报表中心', category: '财务', description: '企业报表统一管理平台，支持多数据源、自动汇总、定时推送等功能', creator: '财务应用组', isFavorite: false },
  { id: 'app-6', name: '知识问答', category: '数智', description: '企业知识库问答系统，支持智能检索、知识图谱、多轮问答等功能', creator: 'AI研发中心', isFavorite: false },
  { id: 'app-7', name: '智能检索', category: '综合', description: '企业级全文检索系统，支持多维度搜索、语义理解、结果排序等功能', creator: '搜索技术组', isFavorite: false },
  { id: 'app-8', name: '会议管理', category: '管理', description: '会议室预约与会议管理系统，支持资源调度、会议纪要、视频会议等功能', creator: '协同办公部', isFavorite: false },
  { id: 'app-9', name: '任务协作', category: '综合', description: '团队任务协作平台，支持任务看板、进度同步、文件共享等功能', creator: '效率工具组', isFavorite: false },
  { id: 'app-10', name: 'CRM系统', category: '市场', description: '客户关系管理系统，支持客户管理、销售漏斗、数据分析等功能', creator: '营销应用组', isFavorite: false },
  { id: 'app-11', name: 'OA办公', category: '政企', description: '企业办公自动化系统，支持公文流转、日程管理、通讯录等功能', creator: '政务应用部', isFavorite: false },
  { id: 'app-12', name: '财务管理', category: '财务', description: '企业财务管理系统，支持预算管理、费用报销、财务报表等功能', creator: '财务应用组', isFavorite: false },
  { id: 'app-13', name: '人事管理', category: '人力', description: '人力资源管理系统，支持招聘管理、员工档案、考勤管理等功能', creator: 'HR应用组', isFavorite: false },
  { id: 'app-14', name: '合同管理', category: '信安', description: '企业合同全生命周期管理，支持合同起草、审批、归档、预警等功能', creator: '法务应用组', isFavorite: false },
  { id: 'app-15', name: '采购管理', category: '管理', description: '企业采购管理系统，支持供应商管理、采购申请、招标比价等功能', creator: '采购应用组', isFavorite: false },
  { id: 'app-16', name: '资产管理', category: '财务', description: '企业资产管理系统，支持资产登记、盘点、折旧、报废等功能', creator: '资产应用组', isFavorite: false },
  { id: 'app-17', name: '数据治理', category: '数智', description: '企业数据治理平台，支持数据标准、数据质量、数据安全等功能', creator: '数据治理部', isFavorite: false },
  { id: 'app-18', name: '智能运维', category: '网络', description: 'IT智能运维平台，支持监控告警、自动化运维、故障诊断等功能', creator: '运维技术组', isFavorite: false },
  { id: 'app-19', name: '安全审计', category: '信安', description: '企业安全审计系统，支持日志分析、行为审计、合规报告等功能', creator: '安全团队', isFavorite: false },
];

export default function AppsMarket() {
  const { toggleAppFavorite } = useApp();
  const [apps, setApps] = useState(enhancedApps);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<AppCategory | '全部'>('全部');
  const [selectedApp, setSelectedApp] = useState<typeof enhancedApps[0] | null>(null);

  const filteredApps = apps.filter(app => {
    const matchesSearch = app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         app.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === '全部' || app.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const favoriteApps = apps.filter(app => app.isFavorite);

  const handleToggleFavorite = (appId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setApps(prev => prev.map(app => 
      app.id === appId ? { ...app, isFavorite: !app.isFavorite } : app
    ));
  };

  const handleAppClick = (app: typeof enhancedApps[0]) => {
    setSelectedApp(app);
  };

  return (
    <div className="flex-1 p-6 overflow-auto">
      <div className="max-w-6xl mx-auto">
        {/* 标题区 */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-slate-800">应用广场</h1>
          <p className="text-slate-500 mt-1">集成第三方应用与工具，一站式办公体验</p>
        </div>

        {/* 搜索 */}
        <div className="flex items-center gap-4 mb-6">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="搜索应用..."
              className="pl-10 bg-white border-slate-200"
            />
          </div>
        </div>

        {/* 推荐区域 */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              精选推荐
            </h2>
            <Button variant="ghost" size="sm" className="text-slate-500 hover:text-slate-700">
              查看更多
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
          <div className="grid grid-cols-4 gap-4">
            {recommendedApps.map((app) => (
              <div
                key={app.id}
                className="relative bg-gradient-to-br from-white to-slate-50 rounded-xl border border-slate-200 p-4 hover:shadow-lg hover:border-blue-200 transition-all cursor-pointer group"
                onClick={() => {
                  const matchedApp = apps.find(a => a.name === app.name);
                  if (matchedApp) handleAppClick(matchedApp);
                }}
              >
                {/* 标签 */}
                <div className={`absolute -top-2 -right-2 px-2 py-0.5 rounded-full text-xs font-medium ${
                  app.tag === '热门' ? 'bg-red-500 text-white' :
                  app.tag === '新品' ? 'bg-green-500 text-white' :
                  app.tag === '精选' ? 'bg-amber-500 text-white' :
                  'bg-blue-500 text-white'
                }`}>
                  {app.tag}
                </div>
                
                <div className="flex items-center gap-3 mb-3">
                  <div className={`w-12 h-12 rounded-xl ${categoryColors[app.category]} flex items-center justify-center text-xl font-bold shadow-sm`}>
                    {app.name.charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-slate-800 truncate">{app.name}</h3>
                    <Badge variant="outline" className="text-xs mt-1">{app.category}</Badge>
                  </div>
                </div>
                
                <p className="text-sm text-slate-500 line-clamp-2 mb-2">{app.description}</p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    {app.hot && <TrendingUp className="w-3.5 h-3.5 text-red-500" />}
                    <div className="flex items-center gap-0.5">
                      {[1,2,3,4,5].map((i) => (
                        <Star key={i} className="w-3 h-3 fill-amber-400 text-amber-400" />
                      ))}
                    </div>
                  </div>
                  <span className="text-xs text-slate-400">10万+人在用</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 分类标签 */}
        <Tabs value={selectedCategory} onValueChange={(v) => setSelectedCategory(v as AppCategory | '全部')} className="mb-6">
          <TabsList className="bg-slate-100 h-auto p-1 flex-wrap">
            <TabsTrigger value="全部" className="data-[state=active]:bg-white data-[state=active]:shadow-sm px-4">
              全部
            </TabsTrigger>
            {appCategories.map((cat) => (
              <TabsTrigger 
                key={cat} 
                value={cat}
                className="data-[state=active]:bg-white data-[state=active]:shadow-sm px-4"
              >
                {cat}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>

        {/* 我的收藏 */}
        {favoriteApps.length > 0 && (
          <div className="mb-8 bg-red-50/50 rounded-xl p-4 border border-red-100">
            <h2 className="text-lg font-semibold text-slate-700 mb-4 flex items-center gap-2">
              <Heart className="w-5 h-5 text-red-500 fill-red-500" />
              我的收藏
            </h2>
            <div className="grid grid-cols-6 gap-3">
              {favoriteApps.map((app) => (
                <div
                  key={app.id}
                  className="flex flex-col items-center p-3 bg-white rounded-xl border border-slate-200 hover:shadow-md transition-shadow cursor-pointer group"
                  onClick={() => handleAppClick(app)}
                >
                  <div className={`w-12 h-12 rounded-xl ${categoryColors[app.category]} flex items-center justify-center text-xl font-bold mb-2`}>
                    {app.name.charAt(0)}
                  </div>
                  <span className="text-sm font-medium text-slate-700 text-center truncate w-full">
                    {app.name}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 应用列表 - 一行三列 */}
        <div>
          <h2 className="text-lg font-semibold text-slate-700 mb-4">
            全部应用 ({filteredApps.length})
          </h2>
          
          <div className="grid grid-cols-3 gap-4">
            {filteredApps.map((app) => (
              <Card 
                key={app.id} 
                className="border-slate-200 hover:shadow-md transition-all cursor-pointer group"
                onClick={() => handleAppClick(app)}
              >
                <CardContent className="p-5">
                  <div className="flex items-start gap-4">
                    <div className={`w-14 h-14 rounded-xl ${categoryColors[app.category]} flex items-center justify-center text-2xl font-bold flex-shrink-0`}>
                      {app.name.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="font-semibold text-slate-800">{app.name}</h3>
                        <Button
                          variant="ghost"
                          size="icon"
                          className={`h-8 w-8 ${app.isFavorite ? 'text-red-500' : 'text-slate-300 hover:text-red-400'}`}
                          onClick={(e) => handleToggleFavorite(app.id, e)}
                        >
                          <Heart className={`w-5 h-5 ${app.isFavorite ? 'fill-red-500' : ''}`} />
                        </Button>
                      </div>
                      <Badge variant="outline" className="text-xs mb-2">{app.category}</Badge>
                      <p className="text-sm text-slate-500 line-clamp-2 mb-2">
                        {app.description}
                      </p>
                      <div className="flex items-center gap-1.5 text-xs text-slate-400">
                        <User className="w-3 h-3" />
                        <span>{app.creator}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* 应用详情弹窗 */}
      <Dialog open={!!selectedApp} onOpenChange={() => setSelectedApp(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <div className="flex items-center gap-4 mb-3">
              <div className={`w-16 h-16 rounded-xl ${selectedApp ? categoryColors[selectedApp.category] : ''} flex items-center justify-center text-3xl font-bold`}>
                {selectedApp?.name.charAt(0)}
              </div>
              <div className="flex-1">
                <DialogTitle className="text-xl">{selectedApp?.name}</DialogTitle>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant="outline">{selectedApp?.category}</Badge>
                  <div className="flex items-center gap-1 text-sm text-slate-400">
                    <User className="w-3.5 h-3.5" />
                    <span>{selectedApp?.creator}</span>
                  </div>
                </div>
              </div>
            </div>
            <DialogDescription className="text-base text-slate-600 leading-relaxed">
              {selectedApp?.description}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex gap-2 sm:gap-2 mt-4">
            <Button 
              variant="outline" 
              onClick={() => selectedApp && handleToggleFavorite(selectedApp.id, {} as React.MouseEvent)}
              className={selectedApp?.isFavorite ? 'text-red-500 border-red-200 hover:bg-red-50' : ''}
            >
              <Heart className={`w-4 h-4 mr-2 ${selectedApp?.isFavorite ? 'fill-red-500' : ''}`} />
              {selectedApp?.isFavorite ? '取消收藏' : '收藏应用'}
            </Button>
            <Button className="bg-blue-500 hover:bg-blue-600">
              打开应用
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
