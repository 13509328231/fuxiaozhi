'use client';

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { 
  ArrowLeft,
  Bell,
  Search,
  Megaphone,
  BookOpen,
  HelpCircle,
  PlayCircle,
  Lightbulb,
  Plus,
  ChevronRight,
  Headphones,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface FeedbackPageProps {
  onBack: () => void;
}

// 模拟反馈记录
const mockFeedbacks = [
  { id: 'FDB-202401015', status: 'processing', content: '登录页面加载缓慢，影响正常使用', time: '2024年1月15日 14:30' },
  { id: 'FDB-20240112', status: 'resolved', content: '希望增加导出功能', time: '2024年1月12日 09:15' },
  { id: 'FDB-20240108', status: 'pending', content: '数据同步功能异常', time: '2024年1月8日 16:45' },
];

const statusConfig: Record<string, { label: string; className: string }> = {
  processing: { label: '处理中', className: 'bg-yellow-100 text-yellow-600' },
  resolved: { label: '已解决', className: 'bg-green-100 text-green-600' },
  pending: { label: '待评估', className: 'bg-slate-100 text-slate-500' },
};

export default function FeedbackPage({ onBack }: FeedbackPageProps) {
  const [showSubmitDialog, setShowSubmitDialog] = useState(false);
  const [feedbackContent, setFeedbackContent] = useState('');
  const [feedbacks, setFeedbacks] = useState(mockFeedbacks);

  const handleSubmitFeedback = () => {
    if (!feedbackContent.trim()) return;
    
    const newFeedback = {
      id: `FDB-${Date.now()}`,
      status: 'pending' as const,
      content: feedbackContent,
      time: new Date().toLocaleString('zh-CN', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }),
    };
    
    setFeedbacks([newFeedback, ...feedbacks]);
    setFeedbackContent('');
    setShowSubmitDialog(false);
  };

  const features = [
    { icon: BookOpen, title: '使用文档', desc: '详细的功能说明和操作指南', color: 'bg-blue-100 text-blue-500', iconBg: 'bg-blue-50' },
    { icon: HelpCircle, title: '常见问题', desc: '快速解答高频疑问', color: 'bg-green-100 text-green-500', iconBg: 'bg-green-50' },
    { icon: PlayCircle, title: '教程视频', desc: '直观的视频教学资源', color: 'bg-purple-100 text-purple-500', iconBg: 'bg-purple-50' },
    { icon: Lightbulb, title: '功能建议', desc: '告诉我们您的改进想法', color: 'bg-amber-100 text-amber-500', iconBg: 'bg-amber-50' },
  ];

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-slate-50/50">
      {/* 顶部导航栏 */}
      <div className="flex items-center justify-between px-6 py-4 bg-white border-b border-slate-200 flex-shrink-0">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={onBack}
            className="gap-2 text-slate-600 hover:bg-slate-100"
          >
            <ArrowLeft className="w-4 h-4" />
            返回
          </Button>
          <h1 className="text-lg font-semibold text-slate-800">帮助与反馈</h1>
        </div>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="w-5 h-5 text-slate-500" />
          <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-red-500 rounded-full" />
        </Button>
      </div>

      {/* 内容区域 */}
      <div className="flex-1 overflow-auto p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* 搜索栏 */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <Input
              placeholder="搜索文档、FAQ 或视频"
              className="pl-12 h-12 bg-white border-slate-200 rounded-xl text-base"
            />
          </div>

          {/* 最新公告 */}
          <div className="flex items-center gap-3 px-4 py-3 bg-blue-50 rounded-xl border border-blue-100">
            <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center flex-shrink-0">
              <Megaphone className="w-4 h-4 text-blue-500" />
            </div>
            <p className="text-sm text-blue-700">
              v2.0 新版本上线，新增AI助手功能，更多智能体验等您探索！
            </p>
          </div>

          {/* 功能入口 */}
          <div className="grid grid-cols-4 gap-4">
            {features.map((feature, index) => (
              <Card 
                key={index} 
                className="border-slate-200 hover:shadow-md transition-shadow cursor-pointer"
              >
                <CardContent className="p-4 text-center">
                  <div className={`w-12 h-12 rounded-xl ${feature.iconBg} flex items-center justify-center mx-auto mb-3`}>
                    <feature.icon className={`w-6 h-6 ${feature.color.split(' ')[1]}`} />
                  </div>
                  <h3 className="font-medium text-slate-800 mb-1">{feature.title}</h3>
                  <p className="text-xs text-slate-500">{feature.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* 问题反馈区 */}
          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 border-0 overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-white mb-1">遇到问题?</h3>
                  <p className="text-blue-100 text-sm">提交错误报告或建议，我们会尽快处理</p>
                </div>
                <Button
                  onClick={() => setShowSubmitDialog(true)}
                  className="bg-white text-blue-600 hover:bg-blue-50"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  提交反馈
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* 我的反馈进度 */}
          <Card className="border-slate-200">
            <CardContent className="p-5">
              <h3 className="font-semibold text-slate-800 mb-4">我的反馈进度</h3>
              <div className="space-y-3">
                {feedbacks.map((feedback) => (
                  <div
                    key={feedback.id}
                    className="flex items-center justify-between p-3 bg-slate-50 rounded-lg hover:bg-slate-100 cursor-pointer transition-colors"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-medium text-slate-600">#{feedback.id}</span>
                        <Badge className={cn("text-xs", statusConfig[feedback.status].className)}>
                          {statusConfig[feedback.status].label}
                        </Badge>
                      </div>
                      <p className="text-sm text-slate-800 truncate">{feedback.content}</p>
                      <p className="text-xs text-slate-400 mt-1">{feedback.time}</p>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400 flex-shrink-0" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 人工客服区 */}
          <Card className="border-slate-200">
            <CardContent className="p-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                    <Headphones className="w-5 h-5 text-blue-500" />
                  </div>
                  <div>
                    <h3 className="font-medium text-slate-800">需要更多帮助?</h3>
                    <p className="text-sm text-slate-500">在线客服: 工作日 9:00-18:00</p>
                  </div>
                </div>
                <Button className="bg-blue-500 hover:bg-blue-600">
                  <Headphones className="w-4 h-4 mr-1" />
                  联系客服
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* 提交反馈弹窗 */}
      <Dialog open={showSubmitDialog} onOpenChange={setShowSubmitDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>提交反馈</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">反馈类型</label>
              <div className="flex gap-2">
                {['功能建议', '问题反馈', '其他'].map((type) => (
                  <Button key={type} variant="outline" size="sm" className="flex-1">
                    {type}
                  </Button>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">详细描述</label>
              <Textarea
                value={feedbackContent}
                onChange={(e) => setFeedbackContent(e.target.value)}
                placeholder="请详细描述您遇到的问题或建议..."
                className="min-h-[120px] resize-none"
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowSubmitDialog(false)}>
              取消
            </Button>
            <Button onClick={handleSubmitFeedback} disabled={!feedbackContent.trim()}>
              提交
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
