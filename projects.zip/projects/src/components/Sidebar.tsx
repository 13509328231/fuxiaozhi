'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { 
  ChevronLeft, 
  ChevronRight, 
  Plus,
  Store,
  LayoutGrid,
  BookOpen,
  User,
} from 'lucide-react';
import Image from 'next/image';
import { cn } from '@/lib/utils';
import { Skill } from '@/types';

export default function Sidebar() {
  const { 
    sidebarCollapsed,
    toggleSidebar,
    skills,
    customSkills,
    activeSkill,
    setActiveSkill,
    currentPage,
    setCurrentPage,
    user,
  } = useApp();

  const allSkills = [...skills, ...customSkills];

  const handleSkillClick = (skill: Skill) => {
    setActiveSkill(skill);
  };

  const menuItems = [
    { id: 'skills', name: '技能广场', icon: Store, page: 'skills' as const },
    { id: 'apps', name: '应用广场', icon: LayoutGrid, page: 'apps' as const },
    { id: 'knowledge', name: '知识中心', icon: BookOpen, page: 'knowledge' as const },
  ];

  return (
    <div 
      className={cn(
        "flex flex-col h-full bg-white border-r border-slate-200 transition-all duration-300",
        sidebarCollapsed ? "w-16" : "w-64"
      )}
    >
      {/* 顶部Logo区 - 固定 */}
      <div className="flex-shrink-0 flex items-center justify-between px-4 py-4 border-b border-slate-100">
        {!sidebarCollapsed && (
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg overflow-hidden bg-gradient-to-br from-blue-500 to-indigo-600 p-0.5">
              <Image 
                src="/logo.png" 
                alt="福小智" 
                width={32} 
                height={32}
                className="rounded-md"
              />
            </div>
            <span className="font-semibold text-slate-800">福小智</span>
          </div>
        )}
        {sidebarCollapsed && (
          <div className="w-8 h-8 rounded-lg overflow-hidden bg-gradient-to-br from-blue-500 to-indigo-600 p-0.5 mx-auto">
            <Image 
              src="/logo.png" 
              alt="福小智" 
              width={32} 
              height={32}
              className="rounded-md"
            />
          </div>
        )}
        {!sidebarCollapsed && (
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleSidebar}
            className="h-7 w-7 text-slate-400 hover:text-slate-600"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
        )}
      </div>

      {/* 中间滚动区域 */}
      <div className="flex-1 overflow-y-auto overflow-x-hidden min-h-0">
        <div className="px-2 py-2">
          {/* 常用技能区 */}
          <div className="space-y-1">
            {!sidebarCollapsed && (
              <div className="px-2 py-2 flex items-center justify-between">
                <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">常用技能</span>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-6 w-6 text-slate-400 hover:text-blue-500"
                  onClick={() => setCurrentPage('apps')}
                  title="添加常用技能"
                >
                  <Plus className="w-3.5 h-3.5" />
                </Button>
              </div>
            )}
            
            {allSkills.map((skill) => (
              <Button
                key={skill.id}
                variant="ghost"
                onClick={() => handleSkillClick(skill)}
                className={cn(
                  "w-full justify-start gap-3 h-10 px-3",
                  sidebarCollapsed && "justify-center px-0",
                  activeSkill?.id === skill.id 
                    ? "bg-blue-50 text-blue-600 hover:bg-blue-100" 
                    : "text-slate-600 hover:bg-slate-50"
                )}
              >
                <span className="text-lg">{skill.icon}</span>
                {!sidebarCollapsed && (
                  <span className="text-sm font-medium truncate">{skill.name}</span>
                )}
              </Button>
            ))}
          </div>

          {/* 功能入口区 */}
          <Separator className="my-3" />
          
          <div className="space-y-1">
            {!sidebarCollapsed && (
              <div className="px-2 py-2">
                <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">功能入口</span>
              </div>
            )}
            
            {menuItems.map((item) => (
              <Button
                key={item.id}
                variant="ghost"
                onClick={() => setCurrentPage(item.page)}
                className={cn(
                  "w-full justify-start gap-3 h-10 px-3",
                  sidebarCollapsed && "justify-center px-0",
                  currentPage === item.page 
                    ? "bg-blue-50 text-blue-600 hover:bg-blue-100" 
                    : "text-slate-600 hover:bg-slate-50"
                )}
              >
                <item.icon className="w-5 h-5" />
                {!sidebarCollapsed && (
                  <span className="text-sm font-medium">{item.name}</span>
                )}
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* 底部用户区 - 固定 */}
      <div className="flex-shrink-0 border-t border-slate-100 px-2 py-2">
        <Button
          variant="ghost"
          onClick={() => setCurrentPage('my-space')}
          className={cn(
            "w-full justify-start gap-3 h-10 px-3",
            sidebarCollapsed && "justify-center px-0",
            currentPage === 'my-space' 
              ? "bg-blue-50 text-blue-600 hover:bg-blue-100" 
              : "text-slate-600 hover:bg-slate-50"
          )}
        >
          <User className="w-5 h-5" />
          {!sidebarCollapsed && (
            <span className="text-sm font-medium">我的空间</span>
          )}
        </Button>
        
        {sidebarCollapsed && (
          <Button
            variant="ghost"
            onClick={toggleSidebar}
            className="w-full justify-center h-10 mt-1 text-slate-400 hover:text-slate-600"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        )}
      </div>
    </div>
  );
}
