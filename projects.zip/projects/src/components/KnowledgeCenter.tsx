'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Search, 
  BookOpen, 
  Users,
  FolderOpen,
  FileText,
  Upload,
  Plus,
  Clock,
  TrendingUp,
  Building2,
  Globe,
} from 'lucide-react';

interface KnowledgeItem {
  id: string;
  title: string;
  type: 'document' | 'article' | 'report';
  category: string;
  updateTime: string;
  source?: string;
}

const personalKnowledge: KnowledgeItem[] = [
  { id: 'p1', title: '项目需求文档汇总', type: 'document', category: '项目', updateTime: '2024-01-15' },
  { id: 'p2', title: '会议纪要合集', type: 'document', category: '会议', updateTime: '2024-01-14' },
  { id: 'p3', title: '技术方案设计', type: 'document', category: '技术', updateTime: '2024-01-13' },
  { id: 'p4', title: '客户需求分析报告', type: 'report', category: '业务', updateTime: '2024-01-12' },
];

const sharedKnowledge: KnowledgeItem[] = [
  { id: 's1', title: '党政政策文件库', type: 'document', category: '政策', updateTime: '2024-01-15', source: '党政办' },
  { id: 's2', title: '管理办法汇编', type: 'document', category: '制度', updateTime: '2024-01-14', source: '综合部' },
  { id: 's3', title: '行业标准规范', type: 'document', category: '标准', updateTime: '2024-01-13', source: '技术部' },
  { id: 's4', title: '项目案例分析', type: 'report', category: '案例', updateTime: '2024-01-12', source: '项目部' },
];

const industryNews = [
  { id: 'n1', title: '2024年数字化转型趋势报告', source: '工信部', time: '2小时前', views: 1234 },
  { id: 'n2', title: '人工智能行业应用白皮书', source: '信通院', time: '5小时前', views: 856 },
  { id: 'n3', title: '企业数据安全最佳实践', source: '安全中心', time: '1天前', views: 2341 },
  { id: 'n4', title: '云计算技术发展报告', source: '科技部', time: '2天前', views: 1567 },
  { id: 'n5', title: '智慧城市建设指南', source: '住建部', time: '3天前', views: 3456 },
];

export default function KnowledgeCenter() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('personal');

  return (
    <div className="flex-1 p-6 overflow-auto">
      <div className="max-w-6xl mx-auto">
        {/* 标题区 */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-slate-800">知识中心</h1>
          <p className="text-slate-500 mt-1">管理个人知识库、共享知识库及行业资讯</p>
        </div>

        {/* 搜索栏 */}
        <div className="flex gap-4 mb-6">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="搜索知识库内容..."
              className="pl-10 bg-white border-slate-200"
            />
          </div>
          <Button>
            <Upload className="w-4 h-4 mr-2" />
            上传文档
          </Button>
        </div>

        {/* 主内容区 */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-slate-100 h-11 p-1">
            <TabsTrigger value="personal" className="data-[state=active]:bg-white data-[state=active]:shadow-sm">
              <BookOpen className="w-4 h-4 mr-2" />
              个人知识库
            </TabsTrigger>
            <TabsTrigger value="shared" className="data-[state=active]:bg-white data-[state=active]:shadow-sm">
              <Users className="w-4 h-4 mr-2" />
              共享知识库
            </TabsTrigger>
            <TabsTrigger value="industry" className="data-[state=active]:bg-white data-[state=active]:shadow-sm">
              <Globe className="w-4 h-4 mr-2" />
              行业资讯
            </TabsTrigger>
          </TabsList>

          {/* 个人知识库 */}
          <TabsContent value="personal">
            <div className="grid grid-cols-3 gap-4">
              {/* 知识库统计 */}
              <Card className="border-slate-200">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center">
                      <FolderOpen className="w-6 h-6 text-blue-500" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-slate-800">12</p>
                      <p className="text-sm text-slate-500">知识库数量</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-slate-200">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center">
                      <FileText className="w-6 h-6 text-green-500" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-slate-800">156</p>
                      <p className="text-sm text-slate-500">文档总数</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-slate-200">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center">
                      <Clock className="w-6 h-6 text-purple-500" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-slate-800">28</p>
                      <p className="text-sm text-slate-500">本周新增</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* 文档列表 */}
            <Card className="border-slate-200 mt-6">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-base">最近文档</CardTitle>
                <Button variant="outline" size="sm">
                  <Plus className="w-4 h-4 mr-1" />
                  新建文档
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {personalKnowledge.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg hover:bg-slate-100 cursor-pointer transition-colors"
                    >
                      <FileText className="w-5 h-5 text-slate-400" />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-slate-700 truncate">{item.title}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <Badge variant="outline" className="text-xs">{item.category}</Badge>
                          <span className="text-xs text-slate-400">{item.updateTime}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* 共享知识库 */}
          <TabsContent value="shared">
            <div className="grid grid-cols-2 gap-4">
              {sharedKnowledge.map((item) => (
                <Card key={item.id} className="border-slate-200 hover:shadow-md transition-shadow cursor-pointer">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-lg bg-indigo-100 flex items-center justify-center">
                        <Building2 className="w-5 h-5 text-indigo-500" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-slate-800">{item.title}</h3>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="outline" className="text-xs">{item.category}</Badge>
                          <span className="text-xs text-slate-400">来源：{item.source}</span>
                        </div>
                        <p className="text-xs text-slate-400 mt-2">更新于 {item.updateTime}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* 行业资讯 */}
          <TabsContent value="industry">
            <div className="flex gap-6">
              {/* 资讯列表 */}
              <div className="flex-1">
                <Card className="border-slate-200">
                  <CardHeader>
                    <CardTitle className="text-base flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-orange-500" />
                      热门资讯
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {industryNews.map((news) => (
                        <div
                          key={news.id}
                          className="p-3 bg-slate-50 rounded-lg hover:bg-slate-100 cursor-pointer transition-colors"
                        >
                          <h3 className="font-medium text-slate-700 mb-1">{news.title}</h3>
                          <div className="flex items-center gap-3 text-xs text-slate-400">
                            <span>{news.source}</span>
                            <span>{news.time}</span>
                            <span>{news.views} 阅读</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* 订阅源 */}
              <div className="w-72">
                <Card className="border-slate-200">
                  <CardHeader>
                    <CardTitle className="text-base">已订阅来源</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {['工信部', '信通院', '安全中心', '科技部'].map((source) => (
                        <div
                          key={source}
                          className="flex items-center justify-between p-2 bg-slate-50 rounded-lg"
                        >
                          <span className="text-sm text-slate-700">{source}</span>
                          <Button variant="ghost" size="sm" className="h-6 text-xs text-slate-400">
                            取消
                          </Button>
                        </div>
                      ))}
                    </div>
                    <Button variant="outline" className="w-full mt-4" size="sm">
                      <Plus className="w-4 h-4 mr-1" />
                      添加订阅源
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
