'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { 
  FileText, 
  Sparkles,
  Palette,
  Layout,
  Zap,
} from 'lucide-react';
import { Skill } from '@/types';
import InputBar from './InputBar';

interface SkillPanelProps {
  skill: Skill;
}

export default function SkillPanel({ skill }: SkillPanelProps) {
  const { addMessage } = useApp();

  // PPT生成状态
  const [pptType, setPptType] = useState('business');
  const [pptStyle, setPptStyle] = useState('professional');
  const [pptPages, setPptPages] = useState(10);
  const [pptColor, setPptColor] = useState('blue');

  // 其他技能的通用状态
  const [inputValue, setInputValue] = useState('');

  // 小智Claw的特殊渲染
  if (skill.id === 'claw') {
    return <ClawPanel />;
  }

  // 会议助手
  if (skill.id === 'meeting') {
    return <MeetingPanel />;
  }

  // PPT生成技能的特定交互
  if (skill.id === 'ppt-gen') {
    return (
      <div className="flex-1 flex flex-col">
        <div className="flex-1 p-8 overflow-auto min-h-[480px]">
          <div className="max-w-3xl mx-auto space-y-6">
            {/* 标题区 */}
            <div className="text-center mb-8">
              <h2 className="text-xl font-semibold text-slate-800">PPT生成助手</h2>
              <p className="text-slate-500 mt-1">需要创建什么主题的演示文稿？</p>
            </div>

            {/* 配置区域 */}
            <div className="grid gap-6">
              {/* 演示文稿类型 */}
              <Card className="border-slate-200 shadow-sm">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base font-medium flex items-center gap-2">
                    <Layout className="w-4 h-4 text-blue-500" />
                    演示文稿类型
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup value={pptType} onValueChange={setPptType} className="grid grid-cols-2 gap-3">
                    {[
                      { value: 'business', label: '商业汇报', icon: '📊' },
                      { value: 'academic', label: '学术报告', icon: '📚' },
                      { value: 'product', label: '产品介绍', icon: '🎯' },
                      { value: 'other', label: '其他类型', icon: '📝' },
                    ].map((type) => (
                      <Label
                        key={type.value}
                        htmlFor={type.value}
                        className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                          pptType === type.value 
                            ? 'border-blue-500 bg-blue-50' 
                            : 'border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <RadioGroupItem value={type.value} id={type.value} className="sr-only" />
                        <span className="text-xl">{type.icon}</span>
                        <span className="font-medium">{type.label}</span>
                      </Label>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>

              {/* 风格选择 */}
              <Card className="border-slate-200 shadow-sm">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base font-medium flex items-center gap-2">
                    <Palette className="w-4 h-4 text-purple-500" />
                    设计风格
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup value={pptStyle} onValueChange={setPptStyle} className="grid grid-cols-4 gap-3">
                    {[
                      { value: 'professional', label: '商务', color: 'bg-slate-100' },
                      { value: 'minimal', label: '简约', color: 'bg-gray-50' },
                      { value: 'creative', label: '创意', color: 'bg-purple-50' },
                      { value: 'tech', label: '科技', color: 'bg-blue-50' },
                    ].map((style) => (
                      <Label
                        key={style.value}
                        htmlFor={style.value}
                        className={`flex flex-col items-center gap-2 p-3 rounded-lg border cursor-pointer transition-colors ${
                          pptStyle === style.value 
                            ? 'border-blue-500 bg-blue-50' 
                            : 'border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <RadioGroupItem value={style.value} id={style.value} className="sr-only" />
                        <div className={`w-10 h-10 rounded-lg ${style.color} border border-slate-200`} />
                        <span className="text-sm font-medium">{style.label}</span>
                      </Label>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>

              {/* 页数和颜色主题 */}
              <div className="grid grid-cols-2 gap-4">
                <Card className="border-slate-200 shadow-sm">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base font-medium flex items-center gap-2">
                      <FileText className="w-4 h-4 text-green-500" />
                      页数
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <Slider
                        value={[pptPages]}
                        onValueChange={([value]) => setPptPages(value)}
                        min={5}
                        max={30}
                        step={1}
                        className="w-full"
                      />
                      <div className="flex justify-between text-sm text-slate-500">
                        <span>5页</span>
                        <span className="font-semibold text-slate-700">{pptPages}页</span>
                        <span>30页</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-slate-200 shadow-sm">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base font-medium flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-yellow-500" />
                      色彩主题
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-5 gap-2">
                      {[
                        { value: 'blue', color: 'bg-blue-500' },
                        { value: 'green', color: 'bg-green-500' },
                        { value: 'orange', color: 'bg-orange-500' },
                        { value: 'purple', color: 'bg-purple-500' },
                        { value: 'red', color: 'bg-red-500' },
                      ].map((theme) => (
                        <button
                          key={theme.value}
                          onClick={() => setPptColor(theme.value)}
                          className={`w-10 h-10 rounded-lg ${theme.color} ${
                            pptColor === theme.value 
                              ? 'ring-2 ring-offset-2 ring-slate-400' 
                              : ''
                          }`}
                        />
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* 内容模板库 */}
              <Card className="border-slate-200 shadow-sm">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base font-medium flex items-center gap-2">
                    <Zap className="w-4 h-4 text-yellow-500" />
                    快速模板
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      '年度工作总结',
                      '项目汇报',
                      '产品发布',
                      '培训课件',
                      '市场分析',
                      '战略规划',
                    ].map((template) => (
                      <Button
                        key={template}
                        variant="outline"
                        className="h-auto py-3 justify-start text-left border-slate-200 hover:border-blue-300 hover:bg-blue-50"
                      >
                        <FileText className="w-4 h-4 mr-2 text-slate-400" />
                        {template}
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* 底部提示 */}
            <div className="bg-blue-50 rounded-lg p-4 flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-4 h-4 text-blue-500" />
              </div>
              <div>
                <p className="text-sm font-medium text-blue-700">提示</p>
                <p className="text-sm text-blue-600 mt-1">
                  在下方输入框中详细描述您的需求，例如："生成一份关于2024年度总结的10页PPT，包含业绩回顾、团队成长、未来规划等章节"
                </p>
              </div>
            </div>
          </div>
        </div>
        <InputBar />
      </div>
    );
  }

  // 其他技能的默认交互
  return (
    <div className="flex-1 flex flex-col">
      <div className="flex-1 flex flex-col items-center justify-center p-8 overflow-auto min-h-[480px]">
        <div className="max-w-2xl w-full">
          <div className="text-center mb-8">
            <h2 className="text-xl font-semibold text-slate-800">{skill.name}</h2>
            <p className="text-slate-500 mt-1">{skill.description}</p>
          </div>

          <Card className="border-slate-200 shadow-sm">
            <CardContent className="p-6">
              <p className="text-slate-600 mb-4">
                请在下方输入您的需求，我将为您提供专业的{skill.name}服务。
              </p>
              <div className="bg-slate-50 rounded-lg p-4">
                <p className="text-sm text-slate-500">
                  示例：{getSkillExample(skill.id)}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      <InputBar />
    </div>
  );
}

function getSkillExample(skillId: string): string {
  const examples: Record<string, string> = {
    'doc-writer': '帮我写一份关于项目验收的请示报告',
    'data-analysis': '分析这份销售数据，找出增长趋势',
    'weekly-report': '生成本周工作总结，主要完成了项目开发和客户沟通',
    'image-gen': '生成一张科技感的背景图，蓝色调',
    'video-gen': '制作一段产品介绍视频，30秒左右',
    'meeting': '整理今天的会议记录，生成会议纪要',
  };
  return examples[skillId] || '请输入您的具体需求';
}

// 小智Claw面板
function ClawPanel() {
  const [inputValue, setInputValue] = useState('');
  const [selectedModel, setSelectedModel] = useState('GLM-5');

  const models = ['GLM-5', 'DeepSeek', 'Kimi', '九天大模型'];

  const handleSend = () => {
    if (!inputValue.trim()) return;
    // 发送消息逻辑
    setInputValue('');
  };

  return (
    <div className="flex-1 flex flex-col">
      {/* 主内容区 */}
      <div className="flex-1 flex flex-col items-center justify-center p-8 overflow-auto min-h-[480px]">
        <div className="w-full max-w-2xl">
          {/* 标题区 */}
          <div className="text-center mb-12">
            <h1 className="text-2xl font-bold text-slate-800 mb-2">小智Claw</h1>
            <p className="text-slate-500">描述你的目标，小智Claw 会分步执行并实时反馈</p>
          </div>

          {/* 功能卡片区 */}
          <div className="grid grid-cols-2 gap-4 mb-8">
            {/* 快速配置卡片 */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 hover:shadow-md transition-shadow cursor-pointer">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-red-50 to-orange-50 rounded-xl flex items-center justify-center flex-shrink-0">
                  <svg viewBox="0 0 24 24" className="w-6 h-6 text-red-500" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <rect x="4" y="4" width="16" height="20" rx="2" className="fill-red-50" />
                    <circle cx="12" cy="10" r="3" className="fill-red-100" />
                    <path d="M8 17h8" strokeLinecap="round" />
                    <path d="M10 20h4" strokeLinecap="round" />
                    <path d="M3 4l2-2h14l2 2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-slate-800 mb-1">快速配置</h3>
                  <p className="text-sm text-slate-500">设置名字、角色，让小智Claw更了解你</p>
                </div>
              </div>
            </div>

            {/* 一键接入飞书卡片 */}
            <div className="bg-white border border-slate-200 rounded-2xl p-5 hover:shadow-md transition-shadow cursor-pointer">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-gradient-to-br from-cyan-50 to-blue-50 rounded-xl flex items-center justify-center flex-shrink-0">
                  <svg viewBox="0 0 24 24" className="w-6 h-6 text-cyan-500" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" className="fill-cyan-50" />
                    <circle cx="12" cy="12" r="1" className="fill-cyan-400" />
                    <circle cx="8" cy="12" r="1" className="fill-cyan-400" />
                    <circle cx="16" cy="12" r="1" className="fill-cyan-400" />
                  </svg>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-slate-800 mb-1">一键接入飞书</h3>
                  <p className="text-sm text-slate-500">自动配置飞书机器人，无需手动操作</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 底部输入区 */}
      <div className="flex-shrink-0 px-6 pb-6">
        <div className="max-w-2xl mx-auto">
          {/* 输入框容器 */}
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm">
            {/* 输入区域 */}
            <div className="p-4">
              <textarea
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="发送给小智Claw"
                className="w-full resize-none outline-none text-slate-800 placeholder-slate-400 text-sm leading-relaxed"
                rows={2}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
              />
            </div>
            
            {/* 底部工具栏 */}
            <div className="flex items-center justify-between px-4 pb-3">
              <div className="flex items-center gap-3">
                {/* 附件按钮 */}
                <button className="p-1.5 text-slate-400 hover:text-slate-600 transition-colors">
                  <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
                
                {/* 模型选择 */}
                <select
                  value={selectedModel}
                  onChange={(e) => setSelectedModel(e.target.value)}
                  className="text-sm text-slate-500 bg-transparent border-none outline-none cursor-pointer hover:text-slate-700"
                >
                  {models.map((model) => (
                    <option key={model} value={model}>{model}</option>
                  ))}
                </select>
              </div>
              
              {/* 发送按钮 */}
              <button
                onClick={handleSend}
                className="w-8 h-8 bg-slate-800 hover:bg-slate-700 rounded-full flex items-center justify-center transition-colors"
              >
                <svg viewBox="0 0 24 24" className="w-4 h-4 text-white" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M12 19V5M5 12l7-7 7 7" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
            </div>
          </div>
          
          {/* 底部提示 */}
          <p className="text-center text-xs text-slate-400 mt-3">
            agent 在本地运行，内容由AI生成
          </p>
        </div>
      </div>
    </div>
  );
}

// 会议助手面板
function MeetingPanel() {
  const [meetingStatus, setMeetingStatus] = useState<'idle' | 'recording' | 'processing'>('idle');

  return (
    <div className="flex-1 flex flex-col">
      <div className="flex-1 flex flex-col items-center justify-center p-8 overflow-auto min-h-[480px]">
        <div className="max-w-2xl w-full">
          <div className="text-center mb-8">
            <h2 className="text-xl font-semibold text-slate-800">会议助手</h2>
            <p className="text-slate-500 mt-1">智能会议纪要生成与管理</p>
          </div>

          <div className="grid gap-4">
            {/* 开始会议按钮 */}
            <Card className="border-slate-200 shadow-sm">
              <CardContent className="p-6 text-center">
                {meetingStatus === 'idle' && (
                  <>
                    <Button
                      size="lg"
                      onClick={() => setMeetingStatus('recording')}
                      className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                    >
                      开始会议录制
                    </Button>
                    <p className="text-sm text-slate-500 mt-4">
                      点击开始后，会议助手将自动记录会议内容
                    </p>
                  </>
                )}
                {meetingStatus === 'recording' && (
                  <>
                    <div className="w-16 h-16 rounded-full bg-red-100 flex items-center justify-center mx-auto mb-4 animate-pulse">
                      <div className="w-8 h-8 rounded-full bg-red-500" />
                    </div>
                    <p className="text-lg font-medium text-slate-700">正在录制中...</p>
                    <p className="text-sm text-slate-500 mt-1">会议时长: 00:05:32</p>
                    <div className="flex justify-center gap-3 mt-4">
                      <Button variant="outline" onClick={() => setMeetingStatus('idle')}>
                        暂停
                      </Button>
                      <Button onClick={() => setMeetingStatus('processing')}>
                        结束会议
                      </Button>
                    </div>
                  </>
                )}
                {meetingStatus === 'processing' && (
                  <>
                    <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-4">
                      <Sparkles className="w-8 h-8 text-blue-500 animate-spin" />
                    </div>
                    <p className="text-lg font-medium text-slate-700">正在生成会议纪要...</p>
                    <p className="text-sm text-slate-500 mt-1">AI正在分析会议内容，请稍候</p>
                  </>
                )}
              </CardContent>
            </Card>

            {/* 功能列表 */}
            <Card className="border-slate-200 shadow-sm">
              <CardHeader>
                <CardTitle className="text-base">功能特性</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { icon: '📝', label: '实时转录' },
                    { icon: '👥', label: '发言人识别' },
                    { icon: '📋', label: '自动摘要' },
                    { icon: '📅', label: '待办提取' },
                  ].map((item) => (
                    <div key={item.label} className="flex items-center gap-2 p-3 bg-slate-50 rounded-lg">
                      <span className="text-xl">{item.icon}</span>
                      <span className="text-sm font-medium">{item.label}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      <InputBar />
    </div>
  );
}
