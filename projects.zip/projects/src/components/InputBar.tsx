'use client';

import React, { useState, useRef } from 'react';
import { useApp } from '@/context/AppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { 
  Mic, 
  Globe,
  Plus,
  Camera,
  ScreenShare,
  Upload,
  X,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Message } from '@/types';

interface InputBarProps {
  compact?: boolean;
}

export default function InputBar({ compact = false }: InputBarProps) {
  const {
    activeSkill,
    selectedModel,
    setSelectedModel,
    models,
    selectedKnowledgeBase,
    setSelectedKnowledgeBase,
    knowledgeBases,
    webSearchEnabled,
    toggleWebSearch,
    addMessage,
    messages,
    clearMessages,
    setActiveSkill,
  } = useApp();

  const [inputValue, setInputValue] = useState('');
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: new Date(),
    };
    addMessage(userMessage);
    setInputValue('');
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const quickActions = [
    { icon: Camera, label: '截图提问', action: () => console.log('截图提问') },
    { icon: ScreenShare, label: '共享屏幕', action: () => console.log('共享屏幕') },
    { icon: Upload, label: '上传图片或文件', action: () => console.log('上传文件') },
  ];

  if (compact) {
    return (
      <div className="bg-white px-4 py-3 border-t border-slate-200">
        <div className="flex items-center gap-2">
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-10 w-10 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full"
              >
                <Plus className="w-5 h-5" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-48 p-2" align="start">
              <div className="space-y-1">
                {quickActions.map((action, index) => (
                  <Button
                    key={index}
                    variant="ghost"
                    className="w-full justify-start gap-3 h-10"
                    onClick={action.action}
                  >
                    <action.icon className="w-4 h-4 text-slate-500" />
                    <span className="text-sm">{action.label}</span>
                  </Button>
                ))}
              </div>
            </PopoverContent>
          </Popover>
          
          <div className="flex-1 relative">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={activeSkill ? `使用${activeSkill.name}...` : '输入您的问题...'}
              className="h-11 w-full px-3 pr-20 bg-slate-50 border border-slate-200 rounded-md outline-none"
            />
            <div className="absolute right-2 top-1/2 -translate-y-1/2">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-slate-400 hover:text-slate-600"
              >
                <Mic className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white px-4 py-3 border-t border-slate-200">
      {/* 当前技能提示 - 移到输入框上方 */}
      {activeSkill && (
        <div className="flex items-center text-sm text-slate-500 mb-2">
          <span>当前技能：{activeSkill.name}</span>
          <button
            onClick={() => {
              clearMessages();
              setActiveSkill(null);
            }}
            className="ml-2 p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded transition-colors"
            title="关闭技能"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}
      
      {/* 输入框 - 整合所有选项，高度增加 */}
      <div className="flex flex-col bg-white border border-slate-200 rounded-xl px-3 py-3 min-h-[100px]">
        {/* 输入区域 - 靠上对齐 */}
        <textarea
          ref={inputRef as React.RefObject<HTMLTextAreaElement>}
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder='发消息或输入"/"选择技能'
          className="flex-1 outline-none text-sm text-slate-800 placeholder-slate-400 bg-transparent resize-none min-h-[40px]"
          rows={2}
        />

        {/* 底部工具栏 - 靠下对齐 */}
        <div className="flex items-center gap-1 mt-2 pt-2 border-t border-slate-100">
          {/* 加号按钮 */}
          <Popover>
            <PopoverTrigger asChild>
              <button className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
                <Plus className="w-5 h-5" />
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-56 p-2" align="start">
              <div className="space-y-1">
                {quickActions.map((action, index) => (
                  <Button
                    key={index}
                    variant="ghost"
                    className="w-full justify-start gap-3 h-10"
                    onClick={action.action}
                  >
                    <action.icon className="w-4 h-4 text-slate-500" />
                    <span className="text-sm">{action.label}</span>
                  </Button>
                ))}
              </div>
            </PopoverContent>
          </Popover>

          {/* 分隔线 */}
          <div className="w-px h-5 bg-slate-200 mx-1" />

          {/* 模型选择 - 隐藏下拉箭头 */}
          <Select value={selectedModel.id} onValueChange={(value) => {
            const model = models.find(m => m.id === value);
            if (model) setSelectedModel(model);
          }}>
            <SelectTrigger className="h-7 w-auto px-2 bg-transparent border-none text-xs text-slate-500 hover:text-slate-700 shadow-none data-[state=open]:ring-0 [&>svg]:hidden">
              <SelectValue placeholder="模型" />
            </SelectTrigger>
            <SelectContent>
              {models.map((model) => (
                <SelectItem key={model.id} value={model.id}>
                  <span className="text-sm">{model.name}</span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* 联网搜索 */}
          <button
            onClick={toggleWebSearch}
            className={cn(
              "flex items-center gap-1 px-2 py-1 rounded text-xs transition-colors",
              webSearchEnabled 
                ? "text-blue-500 bg-blue-50" 
                : "text-slate-400 hover:text-slate-600"
            )}
          >
            <Globe className="w-4 h-4" />
          </button>

          {/* 知识库选择 - 隐藏下拉箭头 */}
          <Select value={selectedKnowledgeBase.id} onValueChange={(value) => {
            const kb = knowledgeBases.find(k => k.id === value);
            if (kb) setSelectedKnowledgeBase(kb);
          }}>
            <SelectTrigger className="h-7 w-auto px-2 bg-transparent border-none text-xs text-slate-500 hover:text-slate-700 shadow-none data-[state=open]:ring-0 [&>svg]:hidden">
              <SelectValue placeholder="知识库" />
            </SelectTrigger>
            <SelectContent>
              {knowledgeBases.map((kb) => (
                <SelectItem key={kb.id} value={kb.id}>
                  <span className="text-sm">{kb.name}</span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* 右侧语音按钮 */}
          <div className="ml-auto">
            <button className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
              <Mic className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
