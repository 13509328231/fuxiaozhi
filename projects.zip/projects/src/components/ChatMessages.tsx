'use client';

import React, { useEffect, useState, useRef } from 'react';
import { useApp } from '@/context/AppContext';
import { Message } from '@/types';
import Image from 'next/image';

export default function ChatMessages() {
  const { messages, activeSkill, selectedModel } = useApp();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [streamingContent, setStreamingContent] = useState<string | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);

  // 自动滚动到底部
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, streamingContent]);

  // 模拟AI响应流式输出
  useEffect(() => {
    const lastMessage = messages[messages.length - 1];
    if (lastMessage?.role === 'user') {
      setIsStreaming(true);
      const response = getAIResponse(lastMessage.content, activeSkill);
      
      let index = 0;
      setStreamingContent('');
      
      const interval = setInterval(() => {
        if (index < response.length) {
          // 每次添加一定数量的字符
          const chunkSize = Math.floor(Math.random() * 3) + 1;
          const chunk = response.slice(index, index + chunkSize);
          setStreamingContent(prev => (prev || '') + chunk);
          index += chunkSize;
        } else {
          clearInterval(interval);
          setIsStreaming(false);
          setStreamingContent(null);
        }
      }, 30);

      return () => clearInterval(interval);
    }
  }, [messages, activeSkill]);

  const getAIResponse = (input: string, skill: typeof activeSkill): string => {
    if (skill?.id === 'ppt-gen') {
      return `好的，我将为您生成关于"${input}"的PPT。\n\n**配置信息：**\n- 演示文稿类型：商业汇报\n- 风格：商务简约\n- 页数：10页\n- 色彩主题：蓝色系\n\n正在生成中，请稍候...`;
    }
    if (skill?.id === 'doc-writer') {
      return `已收到您的写作需求："${input}"\n\n我将按照公文写作规范为您撰写，包括：\n\n1. 标题拟定\n2. 正文结构\n3. 格式排版\n\n请稍候，正在生成中...`;
    }
    if (skill?.id === 'data-analysis') {
      return `我来帮您分析数据：${input}\n\n**分析结果：**\n\n根据您提供的数据，我发现了以下趋势：\n\n1. 整体呈上升趋势\n2. 峰值出现在第三季度\n3. 环比增长约15%\n\n如需更详细的分析报告，请提供更多数据。`;
    }
    if (skill?.id === 'weekly-report') {
      return `根据您的描述，我为您生成了本周工作周报：\n\n**本周工作总结**\n\n${input}\n\n**下周计划**\n- 继续推进项目进度\n- 完成相关文档编写\n- 参与团队协作事项\n\n如有需要调整，请告诉我。`;
    }
    if (skill?.id === 'image-gen') {
      return `我正在为您生成图片：${input}\n\n🎨 图片生成中...\n\n预计需要30秒左右，请稍候。生成完成后会自动展示在对话框中。`;
    }
    return `收到您的消息：${input}\n\n我是福小智智能助手，基于 ${selectedModel.name} 模型为您提供智能服务。${activeSkill ? `\n\n当前使用技能：**${activeSkill.name}**` : ''}\n\n请问还有什么我可以帮助您的吗？`;
  };

  const renderMessage = (message: Message, isLast: boolean) => {
    const isUser = message.role === 'user';
    
    return (
      <div
        key={message.id}
        className={`flex gap-3 ${isUser ? 'flex-row-reverse' : ''} mb-4`}
      >
        {/* 头像 */}
        <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center overflow-hidden ${
          isUser 
            ? 'bg-gradient-to-br from-blue-400 to-indigo-500' 
            : 'bg-gradient-to-br from-blue-500 to-indigo-600 p-0.5'
        }`}>
          {isUser ? (
            <span className="text-white text-sm font-medium">我</span>
          ) : (
            <Image 
              src="/logo.png" 
              alt="福小智" 
              width={28} 
              height={28}
              className="rounded-full"
            />
          )}
        </div>
        
        {/* 消息内容 */}
        <div className={`max-w-[70%] ${isUser ? 'bg-blue-500 text-white' : 'bg-white border border-slate-200'} rounded-2xl px-4 py-3 shadow-sm`}>
          <div className={`text-sm leading-relaxed whitespace-pre-wrap ${isUser ? '' : 'text-slate-700'}`}>
            {formatContent(message.content)}
          </div>
        </div>
      </div>
    );
  };

  const formatContent = (content: string) => {
    // 简单的Markdown格式化
    const lines = content.split('\n');
    return lines.map((line, index) => {
      // 标题
      if (line.startsWith('**') && line.endsWith('**')) {
        return <strong key={index} className="font-semibold">{line.slice(2, -2)}</strong>;
      }
      // 列表项
      if (line.startsWith('- ')) {
        return <div key={index} className="flex gap-2"><span>•</span><span>{line.slice(2)}</span></div>;
      }
      // 编号列表
      if (/^\d+\.\s/.test(line)) {
        return <div key={index} className="ml-2">{line}</div>;
      }
      return <div key={index}>{line || <br />}</div>;
    });
  };

  return (
    <div className="flex-1 overflow-auto p-4">
      <div className="max-w-3xl mx-auto">
        {messages.map((msg, index) => renderMessage(msg, index === messages.length - 1))}
        
        {/* 流式输出中的AI回复 */}
        {isStreaming && streamingContent && (
          <div className="flex gap-3 mb-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 p-0.5 flex items-center justify-center overflow-hidden">
              <Image 
                src="/logo.png" 
                alt="福小智" 
                width={28} 
                height={28}
                className="rounded-full"
              />
            </div>
            <div className="max-w-[70%] bg-white border border-slate-200 rounded-2xl px-4 py-3 shadow-sm">
              <div className="text-sm leading-relaxed whitespace-pre-wrap text-slate-700">
                {formatContent(streamingContent)}
                <span className="inline-block w-1.5 h-4 bg-blue-500 ml-0.5 animate-pulse" />
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>
    </div>
  );
}
