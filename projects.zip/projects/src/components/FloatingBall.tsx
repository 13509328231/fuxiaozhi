'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Maximize2,
  X,
  Send,
  Mic,
} from 'lucide-react';
import Image from 'next/image';
import { cn } from '@/lib/utils';

export default function FloatingBall() {
  const { setWindowState, activeSkill, messages, addMessage } = useApp();
  const [isExpanded, setIsExpanded] = useState(false);
  const [inputValue, setInputValue] = useState('');

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const userMessage = {
      id: Date.now().toString(),
      role: 'user' as const,
      content: inputValue,
      timestamp: new Date(),
    };
    addMessage(userMessage);

    setTimeout(() => {
      const aiMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant' as const,
        content: `收到：${inputValue}`,
        timestamp: new Date(),
      };
      addMessage(aiMessage);
    }, 500);

    setInputValue('');
  };

  // 悬浮球状态
  if (!isExpanded) {
    return (
      <div className="fixed bottom-6 right-6 z-50">
        <button
          onClick={() => setIsExpanded(true)}
          className="w-14 h-14 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 shadow-lg shadow-blue-500/30 hover:shadow-xl hover:shadow-blue-500/40 transition-all duration-300 flex items-center justify-center group"
        >
          <Image 
            src="/logo.png" 
            alt="福小智" 
            width={40} 
            height={40}
            className="rounded-full"
          />
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full border-2 border-white" />
        </button>
      </div>
    );
  }

  // 简易窗口状态
  return (
    <div className="fixed bottom-6 right-6 z-50 w-96 bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
      {/* 标题栏 */}
      <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-blue-500 to-indigo-600">
        <div className="flex items-center gap-2">
          <Image 
            src="/logo.png" 
            alt="福小智" 
            width={24} 
            height={24}
            className="rounded-md"
          />
          <span className="text-white font-medium text-sm">福小智</span>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setWindowState('normal')}
            className="h-7 w-7 text-white/80 hover:text-white hover:bg-white/20"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setIsExpanded(false)}
            className="h-7 w-7 text-white/80 hover:text-white hover:bg-white/20"
          >
            <X className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      {/* 消息区 */}
      <div className="h-64 overflow-y-auto p-3 space-y-2 bg-slate-50">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center">
            <Image 
              src="/logo.png" 
              alt="福小智" 
              width={48} 
              height={48}
              className="rounded-xl mb-3"
            />
            <p className="text-sm text-slate-500">
              你好，我是福小智<br />有什么可以帮助你的？
            </p>
          </div>
        ) : (
          messages.slice(-5).map((msg) => (
            <div
              key={msg.id}
              className={cn(
                "max-w-[85%] px-3 py-2 rounded-lg text-sm",
                msg.role === 'user' 
                  ? "ml-auto bg-blue-500 text-white rounded-br-none" 
                  : "bg-white text-slate-700 rounded-bl-none shadow-sm"
              )}
            >
              {msg.content.substring(0, 200)}
              {msg.content.length > 200 && '...'}
            </div>
          ))
        )}
      </div>

      {/* 输入区 */}
      <div className="p-3 bg-white border-t border-slate-100">
        <div className="flex items-center gap-2">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder={activeSkill ? `使用${activeSkill.name}...` : '输入消息...'}
            className="flex-1 h-9 text-sm bg-slate-50 border-slate-200"
          />
          <Button
            variant="ghost"
            size="icon"
            className="h-9 w-9 text-slate-400"
          >
            <Mic className="w-4 h-4" />
          </Button>
          <Button
            size="icon"
            onClick={handleSend}
            disabled={!inputValue.trim()}
            className="h-9 w-9 bg-blue-500 hover:bg-blue-600"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
