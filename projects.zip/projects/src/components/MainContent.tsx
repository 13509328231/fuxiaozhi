import React from 'react';
import { useApp } from '@/context/AppContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Minus, 
  Maximize2, 
  X, 
  Plus, 
  PanelLeftClose,
  PanelLeft,
  Phone,
} from 'lucide-react';
import Image from 'next/image';
import SkillPanel from './SkillPanel';
import SkillsMarket from './SkillsMarket';
import AppsMarket from './AppsMarket';
import KnowledgeCenter from './KnowledgeCenter';
import MySpace from './MySpace';
import InputBar from './InputBar';
import ChatMessages from './ChatMessages';

export default function MainContent() {
  const { 
    setWindowState,
    sidebarCollapsed,
    toggleSidebar,
    activeSkill,
    currentPage,
    clearMessages,
    setActiveSkill,
    messages,
  } = useApp();

  const handleMinimize = () => {
    setWindowState('minimized');
  };

  const handleMaximize = () => {
    // 最大化逻辑可扩展
  };

  const handleClose = () => {
    setWindowState('minimized');
  };

  const handleNewChat = () => {
    clearMessages();
    setActiveSkill(null);
  };

  const renderContent = () => {
    // 技能页面
    if (currentPage === 'skills') {
      return <SkillsMarket />;
    }
    
    // 应用广场
    if (currentPage === 'apps') {
      return <AppsMarket />;
    }
    
    // 知识中心
    if (currentPage === 'knowledge') {
      return <KnowledgeCenter />;
    }
    
    // 我的空间
    if (currentPage === 'my-space') {
      return <MySpace />;
    }
    
    // 激活的技能
    if (activeSkill) {
      return <SkillPanel skill={activeSkill} />;
    }

    // 默认空白画布
    return (
      <div className="flex-1 flex flex-col">
        {messages.length > 0 ? (
          // 有消息时显示对话
          <ChatMessages />
        ) : (
          // 无消息时显示欢迎页面
          <div className="flex-1 flex flex-col items-center justify-center p-8 overflow-auto min-h-[480px]">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center mb-6 shadow-xl shadow-blue-500/20 p-1">
              <Image 
                src="/logo.png" 
                alt="福小智" 
                width={72} 
                height={72}
                className="rounded-xl"
              />
            </div>
            <h2 className="text-xl font-semibold text-slate-800 mb-2">欢迎使用福小智</h2>
            <p className="text-slate-500 text-center max-w-md mb-8">
              选择左侧技能开始使用，或在下方输入您的问题，我将为您提供智能帮助
            </p>
            <div className="flex flex-wrap justify-center gap-2">
              {['帮我写一份周报', '生成PPT大纲', '分析数据趋势', '总结会议内容'].map((tip) => (
                <Badge 
                  key={tip}
                  variant="secondary"
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 cursor-pointer transition-colors"
                >
                  {tip}
                </Badge>
              ))}
            </div>
          </div>
        )}
        <InputBar />
      </div>
    );
  };

  // 判断是否需要显示输入栏
  const showInputBar = !currentPage || currentPage === 'home' || activeSkill;

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-50/50 overflow-hidden">
      {/* 顶部工具栏 */}
      <div className="flex items-center justify-between px-4 py-2 bg-white border-b border-slate-200 flex-shrink-0">
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleNewChat}
            className="gap-2 text-slate-600 hover:bg-slate-100"
          >
            <Plus className="w-4 h-4" />
            新建对话
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleSidebar}
            className="h-8 w-8 text-slate-400 hover:text-slate-600"
          >
            {sidebarCollapsed ? <PanelLeft className="w-4 h-4" /> : <PanelLeftClose className="w-4 h-4" />}
          </Button>
        </div>

        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            className="gap-2 text-slate-600 hover:bg-slate-100"
          >
            <Phone className="w-4 h-4" />
            语音通话
          </Button>
          <div className="flex items-center gap-0.5 ml-2 bg-slate-100 rounded-lg p-0.5">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleMinimize}
              className="h-7 w-7 text-slate-500 hover:text-slate-700 hover:bg-white"
              title="最小化"
            >
              <Minus className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleMaximize}
              className="h-7 w-7 text-slate-500 hover:text-slate-700 hover:bg-white"
              title="最大化"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleClose}
              className="h-7 w-7 text-slate-500 hover:text-red-500 hover:bg-white"
              title="关闭"
            >
              <X className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      </div>

      {/* 主内容区 - 支持滚动 */}
      <div className="flex-1 overflow-auto">
        {renderContent()}
      </div>
    </div>
  );
}
