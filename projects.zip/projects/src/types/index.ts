// 技能类型
export interface Skill {
  id: string;
  name: string;
  icon: string;
  description: string;
  category: 'common' | 'custom';
  isActive?: boolean;
}

// 应用类型
export interface App {
  id: string;
  name: string;
  category: AppCategory;
  description: string;
  isFavorite?: boolean;
}

// 应用分类
export type AppCategory = 
  | '市场' 
  | '政企' 
  | '综合' 
  | '信安' 
  | '管理' 
  | '人力' 
  | '财务' 
  | '网络' 
  | '数智';

// 知识库类型
export interface KnowledgeBase {
  id: string;
  name: string;
  type: 'personal' | 'shared' | 'industry';
  description?: string;
}

// 模型类型
export interface AIModel {
  id: string;
  name: string;
  provider: string;
}

// 窗口状态
export type WindowState = 'normal' | 'minimized' | 'floating';

// 用户信息
export interface User {
  id: string;
  name: string;
  avatar?: string;
}

// 创作内容类型
export type ContentType = 'ppt' | 'document' | 'image' | 'video' | 'report';

// 创作内容
export interface Creation {
  id: string;
  title: string;
  type: ContentType;
  createdAt: Date;
  updatedAt: Date;
  thumbnail?: string;
}

// 历史记录
export interface HistoryRecord {
  id: string;
  title: string;
  skillId?: string;
  createdAt: Date;
  preview: string;
}

// 收藏项
export interface FavoriteItem {
  id: string;
  type: 'conversation' | 'skill' | 'knowledge' | 'app';
  title: string;
  referenceId: string;
  createdAt: Date;
}

// PPT配置
export interface PPTConfig {
  type: 'business' | 'academic' | 'product' | 'other';
  style: 'professional' | 'minimal' | 'creative' | 'tech';
  pages: number;
  colorTheme: string;
}

// 消息类型
export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}
